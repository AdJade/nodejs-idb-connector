Sample configuration files for:
```
SystemD: adjadekoind.service
Upstart: adjadekoind.conf
OpenRC:  adjadekoind.openrc
         adjadekoind.openrcconf
CentOS:  adjadekoind.init
macOS:    org.adjadekoin.adjadekoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
